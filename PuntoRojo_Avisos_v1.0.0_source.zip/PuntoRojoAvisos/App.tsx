import React, { useEffect, useMemo, useState } from 'react';
import {
  Alert, FlatList, Linking, SafeAreaView, ScrollView, StatusBar,
  StyleSheet, Text, TextInput, TouchableOpacity, View
} from 'react-native';
import * as Contacts from 'expo-contacts';
import AsyncStorage from '@react-native-async-storage/async-storage';

type Client = { id: string; name: string; phone: string; day: '15' | '30' };
type Template = { id: string; title: string; body: string };

const DEFAULT_TEMPLATES: Template[] = [
  { id: 'generated', title: 'Factura generada', body: 'Estimado cliente:\n\nSu factura ha sido generada. Favor realizar su pago a tiempo para evitar contratiempos con su servicio.\n\n¡Gracias por preferir PuntoRojo!' },
  { id: 'due', title: 'Factura vence hoy', body: 'Estimado cliente:\n\nLe recordamos que su factura vence hoy. Favor realizar su pago lo antes posible para evitar inconvenientes con su servicio.\n\n¡Gracias por su atención!' }
];

const colors = { bg: '#090909', panel: '#171717', red: '#E21B2D', white: '#FFFFFF', muted: '#A5A5A5', line: '#303030', green: '#32B875' };

function detectDay(name: string): '15' | '30' | null {
  const normalized = name.toLowerCase().replace(/\s/g, '');
  if (/client-?15\b/.test(normalized)) return '15';
  if (/client-?30\b/.test(normalized)) return '30';
  return null;
}
function cleanName(name: string) {
  return name.replace(/[-_ ]?client-?15\b/ig, '').replace(/[-_ ]?client-?30\b/ig, '').trim() || name;
}

export default function App() {
  const [clients, setClients] = useState<Client[]>([]);
  const [selected, setSelected] = useState<string[]>([]);
  const [sent, setSent] = useState<string[]>([]);
  const [templates, setTemplates] = useState<Template[]>(DEFAULT_TEMPLATES);
  const [activeDay, setActiveDay] = useState<'15' | '30'>('15');
  const [templateId, setTemplateId] = useState('generated');
  const [customBody, setCustomBody] = useState('');
  const [editing, setEditing] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const saved = await AsyncStorage.multiGet(['@pr_clients', '@pr_sent', '@pr_templates']);
        if (saved[0][1]) setClients(JSON.parse(saved[0][1]!));
        if (saved[1][1]) setSent(JSON.parse(saved[1][1]!));
        if (saved[2][1]) setTemplates(JSON.parse(saved[2][1]!));
      } catch { /* start with clean local data */ }
    })();
  }, []);

  useEffect(() => {
    AsyncStorage.setItem('@pr_clients', JSON.stringify(clients)).catch(() => {});
  }, [clients]);
  useEffect(() => {
    AsyncStorage.setItem('@pr_sent', JSON.stringify(sent)).catch(() => {});
  }, [sent]);
  useEffect(() => {
    AsyncStorage.setItem('@pr_templates', JSON.stringify(templates)).catch(() => {});
  }, [templates]);

  const visible = useMemo(() => clients.filter(c => c.day === activeDay), [clients, activeDay]);
  const currentTemplate = templates.find(t => t.id === templateId) || templates[0];

  async function importContacts() {
    setLoading(true);
    try {
      const permission = await Contacts.requestPermissionsAsync();
      if (!permission.granted) {
        Alert.alert('Permiso necesario', 'Autoriza el acceso a contactos para detectar tus clientes.');
        return;
      }
      const result = await Contacts.getContactsAsync({
        fields: [Contacts.Fields.PhoneNumbers],
        sort: Contacts.SortTypes.FirstName
      });
      const imported: Client[] = [];
      for (const c of result.data) {
        const day = detectDay(c.name || '');
        const phone = c.phoneNumbers?.find(p => p.number)?.number?.trim();
        if (day && phone) imported.push({
          id: c.id || `${c.name}-${phone}`,
          name: cleanName(c.name || 'Cliente'),
          phone,
          day
        });
      }
      const unique = Array.from(new Map(imported.map(c => [`${c.phone}-${c.day}`, c])).values());
      setClients(unique);
      setSelected([]);
      Alert.alert('Contactos revisados', `Se encontraron ${unique.length} clientes etiquetados Client-15 o Client-30.`);
    } catch {
      Alert.alert('Error', 'No se pudieron leer los contactos. Inténtalo nuevamente.');
    } finally { setLoading(false); }
  }

  function toggle(id: string) {
    setSelected(old => old.includes(id) ? old.filter(x => x !== id) : [...old, id]);
  }
  function selectAll() {
    const ids = visible.map(c => c.id);
    setSelected(old => ids.every(id => old.includes(id)) ? old.filter(id => !ids.includes(id)) : Array.from(new Set([...old, ...ids])));
  }
  async function openWhatsApp(client: Client, queue: Client[] = [], index = 0) {
    const body = (customBody.trim() || currentTemplate?.body || '').replace(/\{nombre\}/gi, client.name);
    const phone = client.phone.replace(/[^\d+]/g, '').replace(/^\+/, '');
    const url = `https://wa.me/${phone}?text=${encodeURIComponent(body)}`;
    try {
      await Linking.openURL(url);
      Alert.alert('WhatsApp abierto', `Cuando termines de enviar el mensaje a ${client.name}, confirma abajo si fue enviado.`, [
        { text: 'Todavía no', style: 'cancel' },
        { text: 'Sí, enviado', onPress: () => {
          setSent(old => old.includes(client.id) ? old : [...old, client.id]);
          if (index + 1 < queue.length) openWhatsApp(queue[index + 1], queue, index + 1);
          else if (queue.length > 1) Alert.alert('Proceso terminado', 'Terminaste los envíos seleccionados.');
        }}
      ]);
    } catch {
      Alert.alert('No se pudo abrir WhatsApp', 'Verifica que WhatsApp esté instalado y que el número tenga código de país.');
    }
  }
  async function sendSelectedOneByOne() {
    const queue = visible.filter(c => selected.includes(c.id));
    if (!queue.length) { Alert.alert('Selecciona clientes', 'Marca al menos un cliente de esta lista.'); return; }
    Alert.alert('Envío manual', `Se abrirá WhatsApp para ${queue.length} clientes, uno por uno. Debes enviar y confirmar cada mensaje.`, [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Continuar', onPress: () => openWhatsApp(queue[0], queue, 0) }
    ]);
  }
  function saveTemplate() {
    const body = customBody.trim();
    if (!body) { Alert.alert('Mensaje vacío', 'Escribe el mensaje antes de guardarlo.'); return; }
    setTemplates(old => old.map(t => t.id === templateId ? { ...t, body } : t));
    setEditing(false);
    Alert.alert('Guardado', 'La plantilla se guardó en este teléfono.');
  }

  return (
    <SafeAreaView style={s.safe}>
      <StatusBar barStyle="light-content" backgroundColor={colors.bg} />
      <ScrollView contentContainerStyle={s.container}>
        <View style={s.header}>
          <View style={s.logo}><Text style={s.logoText}>PR</Text></View>
          <View style={{flex:1}}><Text style={s.brand}>PUNTOROJO</Text><Text style={s.subtitle}>AVISOS · CLIENTES Y COBROS</Text></View>
          <View style={s.version}><Text style={s.versionText}>v1.0</Text></View>
        </View>

        <Text style={s.heading}>Panel principal</Text>
        <View style={s.stats}>
          <View style={s.stat}><Text style={s.statNum}>{clients.length}</Text><Text style={s.statLabel}>CLIENTES</Text></View>
          <View style={s.stat}><Text style={s.statNum}>{clients.filter(c=>c.day==='15').length}</Text><Text style={s.statLabel}>DÍA 15</Text></View>
          <View style={s.stat}><Text style={s.statNum}>{clients.filter(c=>c.day==='30').length}</Text><Text style={s.statLabel}>DÍA 30</Text></View>
        </View>

        <TouchableOpacity style={s.importBtn} onPress={importContacts} disabled={loading}>
          <Text style={s.importText}>{loading ? 'LEYENDO CONTACTOS...' : '↻  IMPORTAR / ACTUALIZAR CONTACTOS'}</Text>
        </TouchableOpacity>
        <Text style={s.hint}>Solo se mostrarán contactos cuyo nombre contenga Client-15, Client15, Client-30 o Client30.</Text>

        <Text style={s.heading}>Listas de pago</Text>
        <View style={s.tabs}>
          {(['15','30'] as const).map(day => <TouchableOpacity key={day} onPress={()=>{setActiveDay(day);setSelected([]);}} style={[s.tab, activeDay===day && s.tabActive]}><Text style={[s.tabText, activeDay===day && s.tabTextActive]}>CLIENTES DÍA {day}</Text></TouchableOpacity>)}
        </View>

        <View style={s.listHead}>
          <Text style={s.sectionLabel}>{visible.length} CLIENTES EN ESTA LISTA</Text>
          <TouchableOpacity onPress={selectAll}><Text style={s.selectAll}>SELECCIONAR TODOS</Text></TouchableOpacity>
        </View>
        {visible.length === 0 ? <View style={s.empty}><Text style={s.emptyTitle}>No hay clientes todavía</Text><Text style={s.hint}>Pulsa “Importar / actualizar contactos” después de guardar nombres con Client-15 o Client-30.</Text></View> :
          visible.map(c => <TouchableOpacity key={c.id} style={s.client} onPress={()=>toggle(c.id)}>
            <View style={[s.check, selected.includes(c.id) && s.checked]}>{selected.includes(c.id) && <Text style={s.checkMark}>✓</Text>}</View>
            <View style={{flex:1}}><Text style={s.clientName}>{c.name}</Text><Text style={s.clientPhone}>{c.phone}</Text></View>
            {sent.includes(c.id) && <Text style={s.sent}>ENVIADO</Text>}
          </TouchableOpacity>)
        }

        <Text style={s.heading}>Mensaje para WhatsApp</Text>
        <View style={s.panel}>
          <Text style={s.sectionLabel}>PLANTILLA</Text>
          <View style={s.templateRow}>
            {templates.map(t => <TouchableOpacity key={t.id} onPress={()=>{setTemplateId(t.id);setCustomBody(t.body);}} style={[s.template, templateId===t.id && s.templateActive]}><Text style={[s.templateText, templateId===t.id && {color:colors.white}]}>{t.title}</Text></TouchableOpacity>)}
          </View>
          <Text style={s.hint}>Puedes usar {"{nombre}"} para insertar el nombre del cliente.</Text>
          <TextInput multiline value={customBody || currentTemplate?.body || ''} onChangeText={setCustomBody} style={s.messageInput} placeholder="Escribe tu aviso..." placeholderTextColor={colors.muted} />
          <View style={s.row}>
            <TouchableOpacity style={s.secondaryBtn} onPress={()=>setEditing(true)}><Text style={s.secondaryText}>Guardar mensaje</Text></TouchableOpacity>
            <TouchableOpacity style={s.sendBtn} onPress={sendSelectedOneByOne}><Text style={s.sendText}>ABRIR WHATSAPP ({selected.length})</Text></TouchableOpacity>
          </View>
          {editing && <TouchableOpacity style={s.importBtn} onPress={saveTemplate}><Text style={s.importText}>CONFIRMAR GUARDADO</Text></TouchableOpacity>}
        </View>

        <Text style={s.heading}>Historial</Text>
        <View style={s.panel}><Text style={s.history}>{sent.length} avisos confirmados como enviados en este dispositivo.</Text><TouchableOpacity onPress={()=>Alert.alert('Historial', sent.length ? sent.join('\n') : 'Todavía no hay avisos confirmados.')}><Text style={s.selectAll}>VER REGISTRO</Text></TouchableOpacity></View>
        <Text style={s.footer}>PuntoRojo Avisos · Tus contactos permanecen en tu teléfono.</Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe:{flex:1,backgroundColor:colors.bg}, container:{padding:18,paddingBottom:40},
  header:{flexDirection:'row',alignItems:'center',gap:12,marginBottom:26,marginTop:8},
  logo:{width:48,height:48,borderRadius:14,backgroundColor:colors.red,alignItems:'center',justifyContent:'center'},
  logoText:{color:'#fff',fontWeight:'900',fontSize:19},brand:{color:'#fff',fontWeight:'900',fontSize:19,letterSpacing:2},
  subtitle:{color:colors.muted,fontSize:9,letterSpacing:1.4,marginTop:3},version:{borderWidth:1,borderColor:colors.line,borderRadius:20,paddingHorizontal:10,paddingVertical:6},
  versionText:{color:colors.muted,fontSize:11},heading:{color:'#fff',fontSize:19,fontWeight:'800',marginBottom:12,marginTop:18},
  stats:{flexDirection:'row',gap:9,marginBottom:14},stat:{flex:1,backgroundColor:colors.panel,borderRadius:14,padding:14,borderWidth:1,borderColor:colors.line},
  statNum:{color:'#fff',fontSize:25,fontWeight:'900'},statLabel:{color:colors.muted,fontSize:9,letterSpacing:1,marginTop:5},
  importBtn:{backgroundColor:colors.red,borderRadius:12,padding:16,alignItems:'center',marginTop:4},importText:{color:'#fff',fontWeight:'900',fontSize:12,letterSpacing:.5},
  hint:{color:colors.muted,fontSize:11,lineHeight:17,marginTop:9},tabs:{flexDirection:'row',gap:8,marginBottom:14},
  tab:{flex:1,padding:13,borderRadius:10,backgroundColor:colors.panel,borderWidth:1,borderColor:colors.line,alignItems:'center'},
  tabActive:{backgroundColor:'#401016',borderColor:colors.red},tabText:{color:colors.muted,fontWeight:'800',fontSize:11},tabTextActive:{color:'#fff'},
  listHead:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginBottom:8},sectionLabel:{color:colors.muted,fontSize:10,fontWeight:'800',letterSpacing:1},
  selectAll:{color:'#FF5967',fontSize:10,fontWeight:'900'},empty:{padding:20,backgroundColor:colors.panel,borderRadius:12,alignItems:'center'},
  emptyTitle:{color:'#fff',fontWeight:'800',fontSize:14},client:{flexDirection:'row',alignItems:'center',gap:12,padding:13,backgroundColor:colors.panel,borderRadius:11,marginBottom:7,borderWidth:1,borderColor:colors.line},
  check:{width:21,height:21,borderRadius:6,borderWidth:1,borderColor:'#777',alignItems:'center',justifyContent:'center'},checked:{backgroundColor:colors.red,borderColor:colors.red},
  checkMark:{color:'#fff',fontWeight:'900'},clientName:{color:'#fff',fontWeight:'800',fontSize:13},clientPhone:{color:colors.muted,fontSize:11,marginTop:3},
  sent:{color:colors.green,fontSize:9,fontWeight:'900'},panel:{backgroundColor:colors.panel,borderRadius:14,padding:14,borderWidth:1,borderColor:colors.line},
  templateRow:{flexDirection:'row',gap:8,marginTop:10,marginBottom:4},template:{flex:1,padding:10,borderRadius:9,borderWidth:1,borderColor:colors.line},
  templateActive:{backgroundColor:'#401016',borderColor:colors.red},templateText:{color:colors.muted,fontSize:10,fontWeight:'800',textAlign:'center'},
  messageInput:{minHeight:145,color:'#fff',backgroundColor:'#0D0D0D',borderRadius:10,padding:12,textAlignVertical:'top',fontSize:13,marginTop:12,borderWidth:1,borderColor:colors.line},
  row:{flexDirection:'row',gap:8,marginTop:12},secondaryBtn:{padding:12,borderRadius:9,borderWidth:1,borderColor:colors.line,justifyContent:'center},
  secondaryText:{color:'#fff',fontWeight:'800',fontSize:10},sendBtn:{flex:1,backgroundColor:colors.red,padding:12,borderRadius:9,alignItems:'center',justifyContent:'center'},
  sendText:{color:'#fff',fontWeight:'900',fontSize:10},history:{color:'#fff',fontSize:12,marginBottom:10},footer:{color:'#666',fontSize:10,textAlign:'center',marginTop:28}
})
