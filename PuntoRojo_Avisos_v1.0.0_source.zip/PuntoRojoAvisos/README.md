# PuntoRojo Avisos v1.0.0

Aplicación Android inicial para clasificar contactos Client-15 y Client-30 y preparar avisos de WhatsApp para envío manual.

## Requisitos
- Node.js LTS
- Cuenta Expo
- GitHub (opcional para guardar el proyecto)

## Instalar dependencias
```bash
npm install
npx expo install --fix
```

## Probar
```bash
npx expo start
```

## Generar APK con EAS
```bash
npm install -g eas-cli
eas login
eas build:configure
eas build --platform android --profile preview
```

El perfil `preview` está configurado para generar APK.

## Importante
- La app solo importa contactos cuyo nombre contiene Client-15, Client15, Client-30 o Client30.
- WhatsApp se abre con el texto preparado; el usuario debe tocar Enviar.
- La app registra un aviso solo después de que el usuario confirme manualmente.
- Verifica los números y agrega el código de país de República Dominicana (+1 809, +1 829 o +1 849) si no está guardado.
